import 'package:flutter/widgets.dart';

class FFIcons {
  FFIcons._();

  static const String _icomoonFamily = 'Icomoon';

  // icomoon
  static const IconData kcheckmark =
      IconData(0xe900, fontFamily: _icomoonFamily);
  static const IconData kbackspace =
      IconData(0xe920, fontFamily: _icomoonFamily);
  static const IconData karrow = IconData(0xe923, fontFamily: _icomoonFamily);
  static const IconData khome = IconData(0xe9e9, fontFamily: _icomoonFamily);
  static const IconData krefresh = IconData(0xea22, fontFamily: _icomoonFamily);
}
