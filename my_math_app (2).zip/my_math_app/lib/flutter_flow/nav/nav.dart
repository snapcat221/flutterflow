import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:page_transition/page_transition.dart';
import '../flutter_flow_theme.dart';

import '../../index.dart';
import '../../main.dart';
import '../lat_lng.dart';
import '../place.dart';
import 'serialization_util.dart';

export 'package:go_router/go_router.dart';
export 'serialization_util.dart';

const kTransitionInfoKey = '__transition_info__';

class AppStateNotifier extends ChangeNotifier {
  AppStateNotifier._();

  static AppStateNotifier? _instance;
  static AppStateNotifier get instance => _instance ??= AppStateNotifier._();

  bool showSplashImage = true;

  void stopShowingSplashImage() {
    showSplashImage = false;
    notifyListeners();
  }
}

GoRouter createRouter(AppStateNotifier appStateNotifier) => GoRouter(
      initialLocation: '/',
      debugLogDiagnostics: true,
      refreshListenable: appStateNotifier,
      errorBuilder: (context, state) => HomePageWidget(),
      routes: [
        FFRoute(
          name: '_initialize',
          path: '/',
          builder: (context, _) => HomePageWidget(),
        ),
        FFRoute(
          name: 'HomePage',
          path: '/homePage',
          builder: (context, params) => HomePageWidget(),
        ),
        FFRoute(
          name: 'SselectYourlevel',
          path: '/sselectYourlevel',
          builder: (context, params) => SselectYourlevelWidget(),
        ),
        FFRoute(
          name: 'ReadyPageEasy',
          path: '/readyPageEasy',
          builder: (context, params) => ReadyPageEasyWidget(),
        ),
        FFRoute(
          name: 'AQuestion1Page',
          path: '/aQuestion1Page',
          builder: (context, params) => AQuestion1PageWidget(),
        ),
        FFRoute(
          name: 'ACorrectPage1',
          path: '/aCorrectPage1',
          builder: (context, params) => ACorrectPage1Widget(),
        ),
        FFRoute(
          name: 'AIncorrectPage1',
          path: '/aIncorrectPage1',
          builder: (context, params) => AIncorrectPage1Widget(),
        ),
        FFRoute(
          name: 'AQuestion2Page',
          path: '/aQuestion2Page',
          builder: (context, params) => AQuestion2PageWidget(),
        ),
        FFRoute(
          name: 'AQuestion3Page',
          path: '/aQuestion3Page',
          builder: (context, params) => AQuestion3PageWidget(),
        ),
        FFRoute(
          name: 'AQuestion4Page',
          path: '/aQuestion4Page',
          builder: (context, params) => AQuestion4PageWidget(),
        ),
        FFRoute(
          name: 'AQuestion5Page',
          path: '/aQuestion5Page',
          builder: (context, params) => AQuestion5PageWidget(),
        ),
        FFRoute(
          name: 'AQuestion6Page',
          path: '/aQuestion6Page',
          builder: (context, params) => AQuestion6PageWidget(),
        ),
        FFRoute(
          name: 'AQuestion7Page',
          path: '/aQuestion7Page',
          builder: (context, params) => AQuestion7PageWidget(),
        ),
        FFRoute(
          name: 'AQuestion8Page',
          path: '/aQuestion8Page',
          builder: (context, params) => AQuestion8PageWidget(),
        ),
        FFRoute(
          name: 'AQuestion9Page',
          path: '/aQuestion9Page',
          builder: (context, params) => AQuestion9PageWidget(),
        ),
        FFRoute(
          name: 'AQuestiontenPage',
          path: '/aQuestiontenPage',
          builder: (context, params) => AQuestiontenPageWidget(),
        ),
        FFRoute(
          name: 'ACorrectPage2',
          path: '/aCorrectPage2',
          builder: (context, params) => ACorrectPage2Widget(),
        ),
        FFRoute(
          name: 'ACorrectPage3',
          path: '/aCorrectPage3',
          builder: (context, params) => ACorrectPage3Widget(),
        ),
        FFRoute(
          name: 'ACorrectPage4',
          path: '/aCorrectPage4',
          builder: (context, params) => ACorrectPage4Widget(),
        ),
        FFRoute(
          name: 'ACorrectPage5',
          path: '/aCorrectPage5',
          builder: (context, params) => ACorrectPage5Widget(),
        ),
        FFRoute(
          name: 'ACorrectPage6',
          path: '/aCorrectPage6',
          builder: (context, params) => ACorrectPage6Widget(),
        ),
        FFRoute(
          name: 'ACorrectPage7',
          path: '/aCorrectPage7',
          builder: (context, params) => ACorrectPage7Widget(),
        ),
        FFRoute(
          name: 'ACorrectPage8',
          path: '/aCorrectPage8',
          builder: (context, params) => ACorrectPage8Widget(),
        ),
        FFRoute(
          name: 'ACorrectPage9',
          path: '/aCorrectPage9',
          builder: (context, params) => ACorrectPage9Widget(),
        ),
        FFRoute(
          name: 'ACongrats',
          path: '/aCongrats',
          builder: (context, params) => ACongratsWidget(),
        ),
        FFRoute(
          name: 'AIncorrectPage2',
          path: '/aIncorrectPage2',
          builder: (context, params) => AIncorrectPage2Widget(),
        ),
        FFRoute(
          name: 'AIncorrectPage3',
          path: '/aIncorrectPage3',
          builder: (context, params) => AIncorrectPage3Widget(),
        ),
        FFRoute(
          name: 'AIncorrectPage4',
          path: '/aIncorrectPage4',
          builder: (context, params) => AIncorrectPage4Widget(),
        ),
        FFRoute(
          name: 'AIncorrectPage5',
          path: '/aIncorrectPage5',
          builder: (context, params) => AIncorrectPage5Widget(),
        ),
        FFRoute(
          name: 'AIncorrectPage6',
          path: '/aIncorrectPage6',
          builder: (context, params) => AIncorrectPage6Widget(),
        ),
        FFRoute(
          name: 'AIncorrectPage7',
          path: '/aIncorrectPage7',
          builder: (context, params) => AIncorrectPage7Widget(),
        ),
        FFRoute(
          name: 'AIncorrectPage8',
          path: '/aIncorrectPage8',
          builder: (context, params) => AIncorrectPage8Widget(),
        ),
        FFRoute(
          name: 'AIncorrectPage9',
          path: '/aIncorrectPage9',
          builder: (context, params) => AIncorrectPage9Widget(),
        ),
        FFRoute(
          name: 'selectYourlevelAIntmdt',
          path: '/selectYourlevelAIntmdt',
          builder: (context, params) => SelectYourlevelAIntmdtWidget(),
        ),
        FFRoute(
          name: 'selectYourlevelAdd',
          path: '/selectYourlevelAdd',
          builder: (context, params) => SelectYourlevelAddWidget(),
        ),
        FFRoute(
          name: 'DselectYourlevel',
          path: '/dselectYourlevel',
          builder: (context, params) => DselectYourlevelWidget(),
        ),
        FFRoute(
          name: 'ACongratsCopy',
          path: '/aCongratsCopy',
          builder: (context, params) => ACongratsCopyWidget(),
        ),
        FFRoute(
          name: 'AFailure',
          path: '/aFailure',
          builder: (context, params) => AFailureWidget(),
        ),
        FFRoute(
          name: 'AintmReadyPage',
          path: '/aintmReadyPage',
          builder: (context, params) => AintmReadyPageWidget(),
        ),
        FFRoute(
          name: 'AintmQuestion1Page',
          path: '/aintmQuestion1Page',
          builder: (context, params) => AintmQuestion1PageWidget(),
        ),
        FFRoute(
          name: 'AintmCongrats',
          path: '/aintmCongrats',
          builder: (context, params) => AintmCongratsWidget(),
        ),
        FFRoute(
          name: 'AintmCorrectPage1',
          path: '/aintmCorrectPage1',
          builder: (context, params) => AintmCorrectPage1Widget(),
        ),
        FFRoute(
          name: 'AIntmIncorrectPage1',
          path: '/aIntmIncorrectPage1',
          builder: (context, params) => AIntmIncorrectPage1Widget(),
        ),
        FFRoute(
          name: 'AIntmTimeoutPage1',
          path: '/aIntmTimeoutPage1',
          builder: (context, params) => AIntmTimeoutPage1Widget(),
        ),
        FFRoute(
          name: 'AIntmTimeoutPage2',
          path: '/aIntmTimeoutPage2',
          builder: (context, params) => AIntmTimeoutPage2Widget(),
        ),
        FFRoute(
          name: 'AIntmTimeoutPage3',
          path: '/aIntmTimeoutPage3',
          builder: (context, params) => AIntmTimeoutPage3Widget(),
        ),
        FFRoute(
          name: 'AIntmTimeoutPage4',
          path: '/aIntmTimeoutPage4',
          builder: (context, params) => AIntmTimeoutPage4Widget(),
        ),
        FFRoute(
          name: 'AIntmTimeoutPage5',
          path: '/aIntmTimeoutPage5',
          builder: (context, params) => AIntmTimeoutPage5Widget(),
        ),
        FFRoute(
          name: 'AIntmTimeoutPage6',
          path: '/aIntmTimeoutPage6',
          builder: (context, params) => AIntmTimeoutPage6Widget(),
        ),
        FFRoute(
          name: 'AIntmTimeoutPage7',
          path: '/aIntmTimeoutPage7',
          builder: (context, params) => AIntmTimeoutPage7Widget(),
        ),
        FFRoute(
          name: 'AIntmTimeoutPage8',
          path: '/aIntmTimeoutPage8',
          builder: (context, params) => AIntmTimeoutPage8Widget(),
        ),
        FFRoute(
          name: 'AIntmTimeoutPage9',
          path: '/aIntmTimeoutPage9',
          builder: (context, params) => AIntmTimeoutPage9Widget(),
        ),
        FFRoute(
          name: 'AIntmTimeoutPageten',
          path: '/aIntmTimeoutPageten',
          builder: (context, params) => AIntmTimeoutPagetenWidget(),
        ),
        FFRoute(
          name: 'AintmCorrectPage2',
          path: '/aintmCorrectPage2',
          builder: (context, params) => AintmCorrectPage2Widget(),
        ),
        FFRoute(
          name: 'AintmCorrectPage3',
          path: '/aintmCorrectPage3',
          builder: (context, params) => AintmCorrectPage3Widget(),
        ),
        FFRoute(
          name: 'AintmCorrectPage4',
          path: '/aintmCorrectPage4',
          builder: (context, params) => AintmCorrectPage4Widget(),
        ),
        FFRoute(
          name: 'AintmCorrectPage5',
          path: '/aintmCorrectPage5',
          builder: (context, params) => AintmCorrectPage5Widget(),
        ),
        FFRoute(
          name: 'AintmCorrectPage6',
          path: '/aintmCorrectPage6',
          builder: (context, params) => AintmCorrectPage6Widget(),
        ),
        FFRoute(
          name: 'AintmCorrectPage7',
          path: '/aintmCorrectPage7',
          builder: (context, params) => AintmCorrectPage7Widget(),
        ),
        FFRoute(
          name: 'AintmCorrectPage8',
          path: '/aintmCorrectPage8',
          builder: (context, params) => AintmCorrectPage8Widget(),
        ),
        FFRoute(
          name: 'AintmCorrectPage9',
          path: '/aintmCorrectPage9',
          builder: (context, params) => AintmCorrectPage9Widget(),
        ),
        FFRoute(
          name: 'AintmCorrectPageten',
          path: '/aintmCorrectPageten',
          builder: (context, params) => AintmCorrectPagetenWidget(),
        ),
        FFRoute(
          name: 'AIntmIncorrectPage2',
          path: '/aIntmIncorrectPage2',
          builder: (context, params) => AIntmIncorrectPage2Widget(),
        ),
        FFRoute(
          name: 'AIntmIncorrectPage3',
          path: '/aIntmIncorrectPage3',
          builder: (context, params) => AIntmIncorrectPage3Widget(),
        ),
        FFRoute(
          name: 'AIntmIncorrectPage4',
          path: '/aIntmIncorrectPage4',
          builder: (context, params) => AIntmIncorrectPage4Widget(),
        ),
        FFRoute(
          name: 'AIntmIncorrectPage5',
          path: '/aIntmIncorrectPage5',
          builder: (context, params) => AIntmIncorrectPage5Widget(),
        ),
        FFRoute(
          name: 'AIntmIncorrectPage6',
          path: '/aIntmIncorrectPage6',
          builder: (context, params) => AIntmIncorrectPage6Widget(),
        ),
        FFRoute(
          name: 'AIntmIncorrectPage7',
          path: '/aIntmIncorrectPage7',
          builder: (context, params) => AIntmIncorrectPage7Widget(),
        ),
        FFRoute(
          name: 'AIntmIncorrectPage8',
          path: '/aIntmIncorrectPage8',
          builder: (context, params) => AIntmIncorrectPage8Widget(),
        ),
        FFRoute(
          name: 'AIntmIncorrectPage9',
          path: '/aIntmIncorrectPage9',
          builder: (context, params) => AIntmIncorrectPage9Widget(),
        ),
        FFRoute(
          name: 'AIntmIncorrectPageten',
          path: '/aIntmIncorrectPageten',
          builder: (context, params) => AIntmIncorrectPagetenWidget(),
        ),
        FFRoute(
          name: 'AintmQuestion2Page',
          path: '/aintmQuestion2Page',
          builder: (context, params) => AintmQuestion2PageWidget(),
        ),
        FFRoute(
          name: 'AintmQuestion3Page',
          path: '/aintmQuestion3Page',
          builder: (context, params) => AintmQuestion3PageWidget(),
        ),
        FFRoute(
          name: 'AintmQuestion4Page',
          path: '/aintmQuestion4Page',
          builder: (context, params) => AintmQuestion4PageWidget(),
        ),
        FFRoute(
          name: 'AintmQuestion5Page',
          path: '/aintmQuestion5Page',
          builder: (context, params) => AintmQuestion5PageWidget(),
        ),
        FFRoute(
          name: 'AintmQuestion6Page',
          path: '/aintmQuestion6Page',
          builder: (context, params) => AintmQuestion6PageWidget(),
        ),
        FFRoute(
          name: 'AintmQuestion7Page',
          path: '/aintmQuestion7Page',
          builder: (context, params) => AintmQuestion7PageWidget(),
        ),
        FFRoute(
          name: 'AintmQuestion8Page',
          path: '/aintmQuestion8Page',
          builder: (context, params) => AintmQuestion8PageWidget(),
        ),
        FFRoute(
          name: 'AintmQuestion9Page',
          path: '/aintmQuestion9Page',
          builder: (context, params) => AintmQuestion9PageWidget(),
        ),
        FFRoute(
          name: 'AintmQuestiontenPage',
          path: '/aintmQuestiontenPage',
          builder: (context, params) => AintmQuestiontenPageWidget(),
        ),
        FFRoute(
          name: 'AhrdReadyPage',
          path: '/ahrdReadyPage',
          builder: (context, params) => AhrdReadyPageWidget(),
        ),
        FFRoute(
          name: 'AhrdCorrectPage1',
          path: '/ahrdCorrectPage1',
          builder: (context, params) => AhrdCorrectPage1Widget(),
        ),
        FFRoute(
          name: 'AhardCongrats',
          path: '/ahardCongrats',
          builder: (context, params) => AhardCongratsWidget(),
        ),
        FFRoute(
          name: 'AhrdIncorrectPage1',
          path: '/ahrdIncorrectPage1',
          builder: (context, params) => AhrdIncorrectPage1Widget(),
        ),
        FFRoute(
          name: 'AhrdTimeoutPage1',
          path: '/ahrdTimeoutPage1',
          builder: (context, params) => AhrdTimeoutPage1Widget(),
        ),
        FFRoute(
          name: 'AhrdQuestion1Page',
          path: '/ahrdQuestion1Page',
          builder: (context, params) => AhrdQuestion1PageWidget(),
        ),
        FFRoute(
          name: 'AhrdCorrectPage2',
          path: '/ahrdCorrectPage2',
          builder: (context, params) => AhrdCorrectPage2Widget(),
        ),
        FFRoute(
          name: 'AhrdCorrectPage3',
          path: '/ahrdCorrectPage3',
          builder: (context, params) => AhrdCorrectPage3Widget(),
        ),
        FFRoute(
          name: 'AhrdCorrectPage4',
          path: '/ahrdCorrectPage4',
          builder: (context, params) => AhrdCorrectPage4Widget(),
        ),
        FFRoute(
          name: 'AhrdCorrectPage5',
          path: '/ahrdCorrectPage5',
          builder: (context, params) => AhrdCorrectPage5Widget(),
        ),
        FFRoute(
          name: 'AhrdCorrectPage6',
          path: '/ahrdCorrectPage6',
          builder: (context, params) => AhrdCorrectPage6Widget(),
        ),
        FFRoute(
          name: 'AhrdCorrectPage7',
          path: '/ahrdCorrectPage7',
          builder: (context, params) => AhrdCorrectPage7Widget(),
        ),
        FFRoute(
          name: 'AhrdCorrectPage8',
          path: '/ahrdCorrectPage8',
          builder: (context, params) => AhrdCorrectPage8Widget(),
        ),
        FFRoute(
          name: 'AhrdCorrectPage9',
          path: '/ahrdCorrectPage9',
          builder: (context, params) => AhrdCorrectPage9Widget(),
        ),
        FFRoute(
          name: 'AhrdCorrectPageten',
          path: '/ahrdCorrectPageten',
          builder: (context, params) => AhrdCorrectPagetenWidget(),
        ),
        FFRoute(
          name: 'AhrdIncorrectPage2',
          path: '/ahrdIncorrectPage2',
          builder: (context, params) => AhrdIncorrectPage2Widget(),
        ),
        FFRoute(
          name: 'AhrdIncorrectPage3',
          path: '/ahrdIncorrectPage3',
          builder: (context, params) => AhrdIncorrectPage3Widget(),
        ),
        FFRoute(
          name: 'AhrdIncorrectPage4',
          path: '/ahrdIncorrectPage4',
          builder: (context, params) => AhrdIncorrectPage4Widget(),
        ),
        FFRoute(
          name: 'AhrdIncorrectPage5',
          path: '/ahrdIncorrectPage5',
          builder: (context, params) => AhrdIncorrectPage5Widget(),
        ),
        FFRoute(
          name: 'AhrdIncorrectPage6',
          path: '/ahrdIncorrectPage6',
          builder: (context, params) => AhrdIncorrectPage6Widget(),
        ),
        FFRoute(
          name: 'AhrdIncorrectPage7',
          path: '/ahrdIncorrectPage7',
          builder: (context, params) => AhrdIncorrectPage7Widget(),
        ),
        FFRoute(
          name: 'AhrdIncorrectPage8',
          path: '/ahrdIncorrectPage8',
          builder: (context, params) => AhrdIncorrectPage8Widget(),
        ),
        FFRoute(
          name: 'AhrdIncorrectPage9',
          path: '/ahrdIncorrectPage9',
          builder: (context, params) => AhrdIncorrectPage9Widget(),
        ),
        FFRoute(
          name: 'AhrdIncorrectPageten',
          path: '/ahrdIncorrectPageten',
          builder: (context, params) => AhrdIncorrectPagetenWidget(),
        ),
        FFRoute(
          name: 'AhrdQuestion2Page',
          path: '/ahrdQuestion2Page',
          builder: (context, params) => AhrdQuestion2PageWidget(),
        ),
        FFRoute(
          name: 'AhrdQuestion3Page',
          path: '/ahrdQuestion3Page',
          builder: (context, params) => AhrdQuestion3PageWidget(),
        ),
        FFRoute(
          name: 'AhrdQuestion4Page',
          path: '/ahrdQuestion4Page',
          builder: (context, params) => AhrdQuestion4PageWidget(),
        ),
        FFRoute(
          name: 'AhrdQuestion5Page',
          path: '/ahrdQuestion5Page',
          builder: (context, params) => AhrdQuestion5PageWidget(),
        ),
        FFRoute(
          name: 'AhrdQuestion6Page',
          path: '/ahrdQuestion6Page',
          builder: (context, params) => AhrdQuestion6PageWidget(),
        ),
        FFRoute(
          name: 'AhrdQuestion7Page',
          path: '/ahrdQuestion7Page',
          builder: (context, params) => AhrdQuestion7PageWidget(),
        ),
        FFRoute(
          name: 'AhrdQuestion8Page',
          path: '/ahrdQuestion8Page',
          builder: (context, params) => AhrdQuestion8PageWidget(),
        ),
        FFRoute(
          name: 'AhrdQuestion9Page',
          path: '/ahrdQuestion9Page',
          builder: (context, params) => AhrdQuestion9PageWidget(),
        ),
        FFRoute(
          name: 'AhrdQuestiontenPage',
          path: '/ahrdQuestiontenPage',
          builder: (context, params) => AhrdQuestiontenPageWidget(),
        ),
        FFRoute(
          name: 'AhrdTimeoutPage2',
          path: '/ahrdTimeoutPage2',
          builder: (context, params) => AhrdTimeoutPage2Widget(),
        ),
        FFRoute(
          name: 'AhrdTimeoutPage3',
          path: '/ahrdTimeoutPage3',
          builder: (context, params) => AhrdTimeoutPage3Widget(),
        ),
        FFRoute(
          name: 'AhrdTimeoutPage4',
          path: '/ahrdTimeoutPage4',
          builder: (context, params) => AhrdTimeoutPage4Widget(),
        ),
        FFRoute(
          name: 'AhrdTimeoutPage5',
          path: '/ahrdTimeoutPage5',
          builder: (context, params) => AhrdTimeoutPage5Widget(),
        ),
        FFRoute(
          name: 'AhrdTimeoutPage6',
          path: '/ahrdTimeoutPage6',
          builder: (context, params) => AhrdTimeoutPage6Widget(),
        ),
        FFRoute(
          name: 'AhrdTimeoutPage7',
          path: '/ahrdTimeoutPage7',
          builder: (context, params) => AhrdTimeoutPage7Widget(),
        ),
        FFRoute(
          name: 'AhrdTimeoutPage8',
          path: '/ahrdTimeoutPage8',
          builder: (context, params) => AhrdTimeoutPage8Widget(),
        ),
        FFRoute(
          name: 'AhrdTimeoutPage9',
          path: '/ahrdTimeoutPage9',
          builder: (context, params) => AhrdTimeoutPage9Widget(),
        ),
        FFRoute(
          name: 'AhrdTimeoutPageten',
          path: '/ahrdTimeoutPageten',
          builder: (context, params) => AhrdTimeoutPagetenWidget(),
        ),
        FFRoute(
          name: 'DCorrectPage1',
          path: '/dCorrectPage1',
          builder: (context, params) => DCorrectPage1Widget(),
        ),
        FFRoute(
          name: 'SCorrectPage1',
          path: '/sCorrectPage1',
          builder: (context, params) => SCorrectPage1Widget(),
        ),
        FFRoute(
          name: 'MCorrectPage1',
          path: '/mCorrectPage1',
          builder: (context, params) => MCorrectPage1Widget(),
        ),
        FFRoute(
          name: 'SCongrats',
          path: '/sCongrats',
          builder: (context, params) => SCongratsWidget(),
        ),
        FFRoute(
          name: 'DCongrats',
          path: '/dCongrats',
          builder: (context, params) => DCongratsWidget(),
        ),
        FFRoute(
          name: 'MCongrats',
          path: '/mCongrats',
          builder: (context, params) => MCongratsWidget(),
        ),
        FFRoute(
          name: 'SIncorrectPage1',
          path: '/sIncorrectPage1',
          builder: (context, params) => SIncorrectPage1Widget(),
        ),
        FFRoute(
          name: 'SQuestion1Page',
          path: '/sQuestion1Page',
          builder: (context, params) => SQuestion1PageWidget(),
        ),
        FFRoute(
          name: 'SReadyPage',
          path: '/sReadyPage',
          builder: (context, params) => SReadyPageWidget(),
        ),
        FFRoute(
          name: 'MIncorrectPage1',
          path: '/mIncorrectPage1',
          builder: (context, params) => MIncorrectPage1Widget(),
        ),
        FFRoute(
          name: 'DIncorrectPage1',
          path: '/dIncorrectPage1',
          builder: (context, params) => DIncorrectPage1Widget(),
        ),
        FFRoute(
          name: 'MReadyPage',
          path: '/mReadyPage',
          builder: (context, params) => MReadyPageWidget(),
        ),
        FFRoute(
          name: 'DReadyPage',
          path: '/dReadyPage',
          builder: (context, params) => DReadyPageWidget(),
        ),
        FFRoute(
          name: 'MQuestion1Page',
          path: '/mQuestion1Page',
          builder: (context, params) => MQuestion1PageWidget(),
        ),
        FFRoute(
          name: 'DQuestion1Page',
          path: '/dQuestion1Page',
          builder: (context, params) => DQuestion1PageWidget(),
        ),
        FFRoute(
          name: 'SCorrectPage2',
          path: '/sCorrectPage2',
          builder: (context, params) => SCorrectPage2Widget(),
        ),
        FFRoute(
          name: 'SCorrectPage3',
          path: '/sCorrectPage3',
          builder: (context, params) => SCorrectPage3Widget(),
        ),
        FFRoute(
          name: 'SCorrectPage4',
          path: '/sCorrectPage4',
          builder: (context, params) => SCorrectPage4Widget(),
        ),
        FFRoute(
          name: 'SCorrectPage5',
          path: '/sCorrectPage5',
          builder: (context, params) => SCorrectPage5Widget(),
        ),
        FFRoute(
          name: 'SCorrectPage6',
          path: '/sCorrectPage6',
          builder: (context, params) => SCorrectPage6Widget(),
        ),
        FFRoute(
          name: 'SCorrectPage7',
          path: '/sCorrectPage7',
          builder: (context, params) => SCorrectPage7Widget(),
        ),
        FFRoute(
          name: 'SCorrectPage8',
          path: '/sCorrectPage8',
          builder: (context, params) => SCorrectPage8Widget(),
        ),
        FFRoute(
          name: 'SCorrectPage9',
          path: '/sCorrectPage9',
          builder: (context, params) => SCorrectPage9Widget(),
        ),
        FFRoute(
          name: 'SCorrectPageten',
          path: '/sCorrectPageten',
          builder: (context, params) => SCorrectPagetenWidget(),
        ),
        FFRoute(
          name: 'SIncorrectPage2',
          path: '/sIncorrectPage2',
          builder: (context, params) => SIncorrectPage2Widget(),
        ),
        FFRoute(
          name: 'SIncorrectPage4',
          path: '/sIncorrectPage4',
          builder: (context, params) => SIncorrectPage4Widget(),
        ),
        FFRoute(
          name: 'SIncorrectPage5',
          path: '/sIncorrectPage5',
          builder: (context, params) => SIncorrectPage5Widget(),
        ),
        FFRoute(
          name: 'SIncorrectPage6',
          path: '/sIncorrectPage6',
          builder: (context, params) => SIncorrectPage6Widget(),
        ),
        FFRoute(
          name: 'SIncorrectPage7',
          path: '/sIncorrectPage7',
          builder: (context, params) => SIncorrectPage7Widget(),
        ),
        FFRoute(
          name: 'SIncorrectPage8',
          path: '/sIncorrectPage8',
          builder: (context, params) => SIncorrectPage8Widget(),
        ),
        FFRoute(
          name: 'SIncorrectPage9',
          path: '/sIncorrectPage9',
          builder: (context, params) => SIncorrectPage9Widget(),
        ),
        FFRoute(
          name: 'SIncorrectPageten',
          path: '/sIncorrectPageten',
          builder: (context, params) => SIncorrectPagetenWidget(),
        ),
        FFRoute(
          name: 'SIncorrectPage3',
          path: '/sIncorrectPage3',
          builder: (context, params) => SIncorrectPage3Widget(),
        ),
        FFRoute(
          name: 'SQuestion2Page',
          path: '/sQuestion2Page',
          builder: (context, params) => SQuestion2PageWidget(),
        ),
        FFRoute(
          name: 'SQuestion3Page',
          path: '/sQuestion3Page',
          builder: (context, params) => SQuestion3PageWidget(),
        ),
        FFRoute(
          name: 'SQuestion4Page',
          path: '/sQuestion4Page',
          builder: (context, params) => SQuestion4PageWidget(),
        ),
        FFRoute(
          name: 'SQuestion5Page',
          path: '/sQuestion5Page',
          builder: (context, params) => SQuestion5PageWidget(),
        ),
        FFRoute(
          name: 'SQuestion6Page',
          path: '/sQuestion6Page',
          builder: (context, params) => SQuestion6PageWidget(),
        ),
        FFRoute(
          name: 'SQuestion7Page',
          path: '/sQuestion7Page',
          builder: (context, params) => SQuestion7PageWidget(),
        ),
        FFRoute(
          name: 'SQuestion8Page',
          path: '/sQuestion8Page',
          builder: (context, params) => SQuestion8PageWidget(),
        ),
        FFRoute(
          name: 'SQuestion9Page',
          path: '/sQuestion9Page',
          builder: (context, params) => SQuestion9PageWidget(),
        ),
        FFRoute(
          name: 'SQuestiontenPage',
          path: '/sQuestiontenPage',
          builder: (context, params) => SQuestiontenPageWidget(),
        ),
        FFRoute(
          name: 'selectYourlevelPHCopy',
          path: '/selectYourlevelPHCopy',
          builder: (context, params) => SelectYourlevelPHCopyWidget(),
        ),
        FFRoute(
          name: 'MselectYourlevel',
          path: '/mselectYourlevel',
          builder: (context, params) => MselectYourlevelWidget(),
        )
      ].map((r) => r.toRoute(appStateNotifier)).toList(),
    );

extension NavParamExtensions on Map<String, String?> {
  Map<String, String> get withoutNulls => Map.fromEntries(
        entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
}

extension NavigationExtensions on BuildContext {
  void safePop() {
    // If there is only one route on the stack, navigate to the initial
    // page instead of popping.
    if (canPop()) {
      pop();
    } else {
      go('/');
    }
  }
}

extension _GoRouterStateExtensions on GoRouterState {
  Map<String, dynamic> get extraMap =>
      extra != null ? extra as Map<String, dynamic> : {};
  Map<String, dynamic> get allParams => <String, dynamic>{}
    ..addAll(pathParameters)
    ..addAll(queryParameters)
    ..addAll(extraMap);
  TransitionInfo get transitionInfo => extraMap.containsKey(kTransitionInfoKey)
      ? extraMap[kTransitionInfoKey] as TransitionInfo
      : TransitionInfo.appDefault();
}

class FFParameters {
  FFParameters(this.state, [this.asyncParams = const {}]);

  final GoRouterState state;
  final Map<String, Future<dynamic> Function(String)> asyncParams;

  Map<String, dynamic> futureParamValues = {};

  // Parameters are empty if the params map is empty or if the only parameter
  // present is the special extra parameter reserved for the transition info.
  bool get isEmpty =>
      state.allParams.isEmpty ||
      (state.extraMap.length == 1 &&
          state.extraMap.containsKey(kTransitionInfoKey));
  bool isAsyncParam(MapEntry<String, dynamic> param) =>
      asyncParams.containsKey(param.key) && param.value is String;
  bool get hasFutures => state.allParams.entries.any(isAsyncParam);
  Future<bool> completeFutures() => Future.wait(
        state.allParams.entries.where(isAsyncParam).map(
          (param) async {
            final doc = await asyncParams[param.key]!(param.value)
                .onError((_, __) => null);
            if (doc != null) {
              futureParamValues[param.key] = doc;
              return true;
            }
            return false;
          },
        ),
      ).onError((_, __) => [false]).then((v) => v.every((e) => e));

  dynamic getParam<T>(
    String paramName,
    ParamType type, [
    bool isList = false,
  ]) {
    if (futureParamValues.containsKey(paramName)) {
      return futureParamValues[paramName];
    }
    if (!state.allParams.containsKey(paramName)) {
      return null;
    }
    final param = state.allParams[paramName];
    // Got parameter from `extras`, so just directly return it.
    if (param is! String) {
      return param;
    }
    // Return serialized value.
    return deserializeParam<T>(
      param,
      type,
      isList,
    );
  }
}

class FFRoute {
  const FFRoute({
    required this.name,
    required this.path,
    required this.builder,
    this.requireAuth = false,
    this.asyncParams = const {},
    this.routes = const [],
  });

  final String name;
  final String path;
  final bool requireAuth;
  final Map<String, Future<dynamic> Function(String)> asyncParams;
  final Widget Function(BuildContext, FFParameters) builder;
  final List<GoRoute> routes;

  GoRoute toRoute(AppStateNotifier appStateNotifier) => GoRoute(
        name: name,
        path: path,
        pageBuilder: (context, state) {
          final ffParams = FFParameters(state, asyncParams);
          final page = ffParams.hasFutures
              ? FutureBuilder(
                  future: ffParams.completeFutures(),
                  builder: (context, _) => builder(context, ffParams),
                )
              : builder(context, ffParams);
          final child = page;

          final transitionInfo = state.transitionInfo;
          return transitionInfo.hasTransition
              ? CustomTransitionPage(
                  key: state.pageKey,
                  child: child,
                  transitionDuration: transitionInfo.duration,
                  transitionsBuilder: PageTransition(
                    type: transitionInfo.transitionType,
                    duration: transitionInfo.duration,
                    reverseDuration: transitionInfo.duration,
                    alignment: transitionInfo.alignment,
                    child: child,
                  ).transitionsBuilder,
                )
              : MaterialPage(key: state.pageKey, child: child);
        },
        routes: routes,
      );
}

class TransitionInfo {
  const TransitionInfo({
    required this.hasTransition,
    this.transitionType = PageTransitionType.fade,
    this.duration = const Duration(milliseconds: 300),
    this.alignment,
  });

  final bool hasTransition;
  final PageTransitionType transitionType;
  final Duration duration;
  final Alignment? alignment;

  static TransitionInfo appDefault() => TransitionInfo(hasTransition: false);
}
