import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'select_yourlevel_p_h_copy_model.dart';
export 'select_yourlevel_p_h_copy_model.dart';

class SelectYourlevelPHCopyWidget extends StatefulWidget {
  const SelectYourlevelPHCopyWidget({Key? key}) : super(key: key);

  @override
  _SelectYourlevelPHCopyWidgetState createState() =>
      _SelectYourlevelPHCopyWidgetState();
}

class _SelectYourlevelPHCopyWidgetState
    extends State<SelectYourlevelPHCopyWidget> {
  late SelectYourlevelPHCopyModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  final _unfocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SelectYourlevelPHCopyModel());
  }

  @override
  void dispose() {
    _model.dispose();

    _unfocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(_unfocusNode),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Color(0xFFFFDEDE),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Container(
                width: 390.0,
                height: 100.0,
                decoration: BoxDecoration(
                  color: Color(0xFFA74747),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(50.0),
                    bottomRight: Radius.circular(50.0),
                    topLeft: Radius.circular(0.0),
                    topRight: Radius.circular(0.0),
                  ),
                ),
                child: Align(
                  alignment: AlignmentDirectional(0.0, -0.1),
                  child: Text(
                    'Math4Life',
                    textAlign: TextAlign.center,
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Boogaloo',
                          color: Colors.white,
                          fontSize: 67.0,
                        ),
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 30.0, 0.0, 0.0),
                  child: Material(
                    color: Colors.transparent,
                    elevation: 5.0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                    child: Container(
                      width: 338.0,
                      height: 132.0,
                      decoration: BoxDecoration(
                        color: Color(0xFFDC9191),
                        borderRadius: BorderRadius.circular(30.0),
                        border: Border.all(
                          color: Color(0xFFA74747),
                          width: 7.0,
                        ),
                      ),
                      child: Align(
                        alignment: AlignmentDirectional(0.0, -0.05),
                        child: Text(
                          'Addition',
                          textAlign: TextAlign.center,
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Boogaloo',
                                    fontSize: 81.0,
                                    lineHeight: 1.0,
                                  ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 10.0),
                  child: Material(
                    color: Colors.transparent,
                    elevation: 5.0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                    child: Container(
                      width: 338.0,
                      height: 154.0,
                      decoration: BoxDecoration(
                        color: Color(0xFFD96B6B),
                        borderRadius: BorderRadius.circular(30.0),
                        border: Border.all(
                          color: Color(0xFFA74747),
                          width: 7.0,
                        ),
                      ),
                      child: Align(
                        alignment: AlignmentDirectional(0.0, 0.05),
                        child: Text(
                          'Select your level:',
                          textAlign: TextAlign.center,
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Boogaloo',
                                    fontSize: 64.0,
                                  ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Align(
                  alignment: AlignmentDirectional(0.0, 0.0),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 70.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        FFButtonWidget(
                          onPressed: () async {
                            context.pushNamed(
                              'ReadyPageEasy',
                              extra: <String, dynamic>{
                                kTransitionInfoKey: TransitionInfo(
                                  hasTransition: true,
                                  transitionType:
                                      PageTransitionType.rightToLeft,
                                ),
                              },
                            );
                          },
                          text: 'Level 1',
                          options: FFButtonOptions(
                            width: 338.0,
                            height: 70.0,
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            iconPadding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            color: Color(0xFFD9D9D9),
                            textStyle: FlutterFlowTheme.of(context)
                                .titleSmall
                                .override(
                                  fontFamily: 'Boogaloo',
                                  color:
                                      FlutterFlowTheme.of(context).primaryText,
                                  fontSize: 55.0,
                                ),
                            elevation: 5.0,
                            borderSide: BorderSide(
                              color: Color(0xFFA74747),
                              width: 5.0,
                            ),
                            borderRadius: BorderRadius.circular(12.0),
                          ),
                        ),
                        FFButtonWidget(
                          onPressed: () {
                            print('Button pressed ...');
                          },
                          text: 'Level 2',
                          options: FFButtonOptions(
                            width: 338.0,
                            height: 70.0,
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            iconPadding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            color: Color(0xFFD9D9D9),
                            textStyle: FlutterFlowTheme.of(context)
                                .titleSmall
                                .override(
                                  fontFamily: 'Boogaloo',
                                  color:
                                      FlutterFlowTheme.of(context).primaryText,
                                  fontSize: 55.0,
                                ),
                            elevation: 5.0,
                            borderSide: BorderSide(
                              color: Color(0xFFA74747),
                              width: 5.0,
                            ),
                            borderRadius: BorderRadius.circular(12.0),
                          ),
                        ),
                        FFButtonWidget(
                          onPressed: () async {
                            context.pushNamed('AhrdReadyPage');
                          },
                          text: 'Level 3',
                          options: FFButtonOptions(
                            width: 338.0,
                            height: 70.0,
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            iconPadding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 0.0, 0.0),
                            color: Color(0xFFD9D9D9),
                            textStyle: FlutterFlowTheme.of(context)
                                .titleSmall
                                .override(
                                  fontFamily: 'Boogaloo',
                                  color:
                                      FlutterFlowTheme.of(context).primaryText,
                                  fontSize: 53.0,
                                ),
                            elevation: 5.0,
                            borderSide: BorderSide(
                              color: Color(0xFFA74747),
                              width: 5.0,
                            ),
                            borderRadius: BorderRadius.circular(12.0),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
