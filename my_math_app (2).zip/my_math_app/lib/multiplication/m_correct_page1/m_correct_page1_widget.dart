import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'm_correct_page1_model.dart';
export 'm_correct_page1_model.dart';

class MCorrectPage1Widget extends StatefulWidget {
  const MCorrectPage1Widget({Key? key}) : super(key: key);

  @override
  _MCorrectPage1WidgetState createState() => _MCorrectPage1WidgetState();
}

class _MCorrectPage1WidgetState extends State<MCorrectPage1Widget> {
  late MCorrectPage1Model _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  final _unfocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => MCorrectPage1Model());
  }

  @override
  void dispose() {
    _model.dispose();

    _unfocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(_unfocusNode),
      child: WillPopScope(
        onWillPop: () async => false,
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: Color(0xFFFFDEDE),
          body: SafeArea(
            top: true,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: 390.0,
                  height: 100.0,
                  decoration: BoxDecoration(
                    color: Color(0xFFA74747),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(50.0),
                      bottomRight: Radius.circular(50.0),
                      topLeft: Radius.circular(0.0),
                      topRight: Radius.circular(0.0),
                    ),
                  ),
                  child: Align(
                    alignment: AlignmentDirectional(0.0, -0.1),
                    child: Text(
                      'Math4Life',
                      textAlign: TextAlign.center,
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Boogaloo',
                            color: Colors.white,
                            fontSize: 67.0,
                          ),
                    ),
                  ),
                ),
                Align(
                  alignment: AlignmentDirectional(0.0, 0.0),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 70.0, 0.0, 60.0),
                    child: Material(
                      color: Colors.transparent,
                      elevation: 5.0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                      child: Container(
                        width: 340.0,
                        height: 145.0,
                        decoration: BoxDecoration(
                          color: Color(0xFFDC9191),
                          borderRadius: BorderRadius.circular(30.0),
                          border: Border.all(
                            color: Color(0xFFA74747),
                            width: 7.0,
                          ),
                        ),
                        child: Align(
                          alignment: AlignmentDirectional(0.0, -0.25),
                          child: Text(
                            'Correct\nNext question...',
                            textAlign: TextAlign.center,
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Boogaloo',
                                  fontSize: 53.0,
                                  lineHeight: 1.0,
                                ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 60.0),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8.0),
                    child: Image.asset(
                      'assets/images/checkmark.png',
                      width: 237.0,
                      height: 237.0,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                Flexible(
                  child: FFButtonWidget(
                    onPressed: () async {
                      context.pushNamed(
                        'AQuestion2Page',
                        extra: <String, dynamic>{
                          kTransitionInfoKey: TransitionInfo(
                            hasTransition: true,
                            transitionType: PageTransitionType.rightToLeft,
                          ),
                        },
                      );
                    },
                    text: 'Next question',
                    options: FFButtonOptions(
                      width: 338.0,
                      height: 101.0,
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                      iconPadding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                      color: Color(0xFFDC9191),
                      textStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                fontFamily: 'Boogaloo',
                                color: FlutterFlowTheme.of(context).primaryText,
                                fontSize: 60.0,
                              ),
                      elevation: 5.0,
                      borderSide: BorderSide(
                        color: Color(0xFFA74747),
                        width: 7.0,
                      ),
                      borderRadius: BorderRadius.circular(17.0),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
