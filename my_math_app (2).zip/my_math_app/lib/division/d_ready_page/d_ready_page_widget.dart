import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'd_ready_page_model.dart';
export 'd_ready_page_model.dart';

class DReadyPageWidget extends StatefulWidget {
  const DReadyPageWidget({Key? key}) : super(key: key);

  @override
  _DReadyPageWidgetState createState() => _DReadyPageWidgetState();
}

class _DReadyPageWidgetState extends State<DReadyPageWidget> {
  late DReadyPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  final _unfocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DReadyPageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    _unfocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(_unfocusNode),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Color(0xFFFFDEDE),
        body: SafeArea(
          top: true,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Container(
                width: 390.0,
                height: 100.0,
                decoration: BoxDecoration(
                  color: Color(0xFFA74747),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(50.0),
                    bottomRight: Radius.circular(50.0),
                    topLeft: Radius.circular(0.0),
                    topRight: Radius.circular(0.0),
                  ),
                ),
                child: Align(
                  alignment: AlignmentDirectional(0.0, -0.1),
                  child: Text(
                    'Math4Life',
                    textAlign: TextAlign.center,
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Boogaloo',
                          color: Colors.white,
                          fontSize: 67.0,
                        ),
                  ),
                ),
              ),
              Align(
                alignment: AlignmentDirectional(0.0, 0.0),
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 40.0, 0.0, 60.0),
                  child: Material(
                    color: Colors.transparent,
                    elevation: 5.0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                    child: Container(
                      width: 338.0,
                      height: 191.0,
                      decoration: BoxDecoration(
                        color: Color(0xFFDC9191),
                        borderRadius: BorderRadius.circular(30.0),
                        border: Border.all(
                          color: Color(0xFFA74747),
                          width: 7.0,
                        ),
                      ),
                      child: Align(
                        alignment: AlignmentDirectional(0.0, -0.25),
                        child: Text(
                          'Ready?\nOn your marks...\nGet set...',
                          textAlign: TextAlign.center,
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Boogaloo',
                                    fontSize: 53.0,
                                    lineHeight: 1.1,
                                  ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 60.0),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8.0),
                  child: Image.asset(
                    'assets/images/question_mark_asset.png',
                    width: 201.0,
                    height: 201.0,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Flexible(
                child: FFButtonWidget(
                  onPressed: () async {
                    context.pushNamed('AQuestion1Page');
                  },
                  text: 'GO!',
                  options: FFButtonOptions(
                    width: 263.0,
                    height: 101.0,
                    padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    iconPadding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                    color: Color(0xFFDC9191),
                    textStyle: FlutterFlowTheme.of(context).titleSmall.override(
                          fontFamily: 'Boogaloo',
                          color: FlutterFlowTheme.of(context).primaryText,
                          fontSize: 72.0,
                        ),
                    elevation: 5.0,
                    borderSide: BorderSide(
                      color: Color(0xFFA74747),
                      width: 7.0,
                    ),
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
