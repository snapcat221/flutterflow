import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'd_congrats_model.dart';
export 'd_congrats_model.dart';

class DCongratsWidget extends StatefulWidget {
  const DCongratsWidget({Key? key}) : super(key: key);

  @override
  _DCongratsWidgetState createState() => _DCongratsWidgetState();
}

class _DCongratsWidgetState extends State<DCongratsWidget> {
  late DCongratsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  final _unfocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => DCongratsModel());
  }

  @override
  void dispose() {
    _model.dispose();

    _unfocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(_unfocusNode),
      child: WillPopScope(
        onWillPop: () async => false,
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: Color(0xFFFFDEDE),
          body: SafeArea(
            top: true,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: 390.0,
                  height: 100.0,
                  decoration: BoxDecoration(
                    color: Color(0xFFA74747),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(50.0),
                      bottomRight: Radius.circular(50.0),
                      topLeft: Radius.circular(0.0),
                      topRight: Radius.circular(0.0),
                    ),
                  ),
                  child: Align(
                    alignment: AlignmentDirectional(0.0, -0.1),
                    child: Text(
                      'Math4Life',
                      textAlign: TextAlign.center,
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Boogaloo',
                            color: Colors.white,
                            fontSize: 67.0,
                          ),
                    ),
                  ),
                ),
                Padding(
                  padding:
                      EdgeInsetsDirectional.fromSTEB(10.0, 10.0, 10.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(
                        Icons.check,
                        color: Color(0xFF00FF3D),
                        size: 32.0,
                      ),
                      Icon(
                        Icons.check,
                        color: Color(0xFF00FF3D),
                        size: 32.0,
                      ),
                      Icon(
                        Icons.check,
                        color: Color(0xFF00FF3D),
                        size: 32.0,
                      ),
                      Icon(
                        Icons.check,
                        color: Color(0xFF00FF3D),
                        size: 32.0,
                      ),
                      Icon(
                        Icons.check,
                        color: Color(0xFF00FF3D),
                        size: 32.0,
                      ),
                      Icon(
                        Icons.clear_outlined,
                        color: Color(0xFFFF0004),
                        size: 35.0,
                      ),
                      Icon(
                        Icons.check,
                        color: Color(0xFF00FF3D),
                        size: 32.0,
                      ),
                      Icon(
                        Icons.check,
                        color: Color(0xFF00FF3D),
                        size: 32.0,
                      ),
                      Icon(
                        Icons.check,
                        color: Color(0xFF00FF3D),
                        size: 32.0,
                      ),
                      Icon(
                        Icons.check,
                        color: Color(0xFF00FF3D),
                        size: 32.0,
                      ),
                    ],
                  ),
                ),
                Align(
                  alignment: AlignmentDirectional(0.0, 0.0),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 15.0),
                    child: Material(
                      color: Colors.transparent,
                      elevation: 5.0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                      child: Container(
                        width: 336.0,
                        height: 130.0,
                        decoration: BoxDecoration(
                          color: Color(0xFFDC9191),
                          borderRadius: BorderRadius.circular(30.0),
                          border: Border.all(
                            color: Color(0xFFA74747),
                            width: 7.0,
                          ),
                        ),
                        child: Align(
                          alignment: AlignmentDirectional(0.0, -0.25),
                          child: Text(
                            'Congrats!',
                            textAlign: TextAlign.center,
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Boogaloo',
                                  fontSize: 81.0,
                                  lineHeight: 1.0,
                                ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Align(
                  alignment: AlignmentDirectional(0.0, 0.0),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 20.0),
                    child: Material(
                      color: Colors.transparent,
                      elevation: 5.0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                      child: Container(
                        width: 338.0,
                        height: 130.0,
                        decoration: BoxDecoration(
                          color: Color(0xFFD96B6B),
                          borderRadius: BorderRadius.circular(30.0),
                          border: Border.all(
                            color: Color(0xFFA74747),
                            width: 7.0,
                          ),
                        ),
                        child: Align(
                          alignment: AlignmentDirectional(0.0, 0.05),
                          child: Text(
                            'You got 90%!',
                            textAlign: TextAlign.center,
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Boogaloo',
                                  fontSize: 64.0,
                                  lineHeight: 1.0,
                                ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8.0),
                  child: Image.asset(
                    'assets/images/4_1024x1024.webp',
                    width: 150.0,
                    height: 150.0,
                    fit: BoxFit.cover,
                  ),
                ),
                Flexible(
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        context.pushNamed(
                          'selectYourlevelAdd',
                          extra: <String, dynamic>{
                            kTransitionInfoKey: TransitionInfo(
                              hasTransition: true,
                              transitionType: PageTransitionType.rightToLeft,
                            ),
                          },
                        );
                      },
                      text: 'Next level',
                      options: FFButtonOptions(
                        width: 338.0,
                        height: 101.0,
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        iconPadding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        color: Color(0xFFDC9191),
                        textStyle: FlutterFlowTheme.of(context)
                            .titleSmall
                            .override(
                              fontFamily: 'Boogaloo',
                              color: FlutterFlowTheme.of(context).primaryText,
                              fontSize: 60.0,
                            ),
                        elevation: 5.0,
                        borderSide: BorderSide(
                          color: Color(0xFFA74747),
                          width: 7.0,
                        ),
                        borderRadius: BorderRadius.circular(17.0),
                      ),
                    ),
                  ),
                ),
                Flexible(
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(0.0, 25.0, 0.0, 0.0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        context.pushNamed(
                          'HomePage',
                          extra: <String, dynamic>{
                            kTransitionInfoKey: TransitionInfo(
                              hasTransition: true,
                              transitionType: PageTransitionType.rightToLeft,
                            ),
                          },
                        );
                      },
                      text: 'Home',
                      icon: Icon(
                        Icons.home_rounded,
                        color: Color(0xFFA74747),
                        size: 50.0,
                      ),
                      options: FFButtonOptions(
                        width: 187.0,
                        height: 85.0,
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        iconPadding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        color: Color(0xFFDC9191),
                        textStyle: FlutterFlowTheme.of(context)
                            .titleSmall
                            .override(
                              fontFamily: 'Boogaloo',
                              color: FlutterFlowTheme.of(context).primaryText,
                              fontSize: 45.0,
                            ),
                        elevation: 5.0,
                        borderSide: BorderSide(
                          color: Color(0xFFA74747),
                          width: 7.0,
                        ),
                        borderRadius: BorderRadius.circular(17.0),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
